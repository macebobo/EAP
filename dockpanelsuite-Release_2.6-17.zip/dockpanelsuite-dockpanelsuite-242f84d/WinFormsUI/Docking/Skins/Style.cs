﻿namespace WeifenLuo.WinFormsUI.Docking.Skins
{
    public enum Style
    {
        VisualStudio2005 = 1
    }
}
